package Garage;

import java.util.Arrays;
import java.util.Comparator;

public class MostFit extends Park {

	@Override
	void parkProcess(double cw, double cp, String modelYear, int id, String modelName) throws Exception {
		// TODO Auto-generated method stub
		Arrays.sort(Configration.slots,new Comparator<Slot>() {
			@Override
			public int compare(Slot o1, Slot o2) {
				double x =o1.width - o2.width;
				int num =0 ;
				if(x==0)num= 0;
				else if (x>0)num=1; 
				else if (x<0)num= -1;
				return num;
			}
		});
		Arrays.sort(Configration.slots,new Comparator<Slot>() {
			@Override
			public int compare(Slot o1, Slot o2) {
	        	double x = o1.depth - o2.depth;
	        	int num =0 ;
	        	if(x==0)num= 0;
	        	else if (x>0)num=1; 
	        	else if (x<0)num= -1;
				return num;
			}
		});
		boolean flag1 =false ; 
		int i =0 ;
		for( i= 0;i<Configration.slots.length;i++) {
			if(cp<=Configration.slots[i].depth&&cw<=Configration.slots[i].width&&!Configration.slots[i].isActive) {
				flag1 = true;
				break;
			}
		}
		double firstPair [] = {i,Configration.slots[i].width*Configration.slots[i].depth};
		Arrays.sort(Configration.slots,new Comparator<Slot>() {
			@Override
			public int compare(Slot o1, Slot o2) {
				double x =o1.width - o2.width;
				int num =0 ;
				if(x==0)num= 0;
				else if (x>0)num=1; 
				else if (x<0)num= -1;
				return num;
			}
		});
		boolean flag2 =false ; 
		i =0 ;
		for( i= 0;i<Configration.slots.length;i++) {
			if(cp<=Configration.slots[i].depth&&cw<=Configration.slots[i].width&&!Configration.slots[i].isActive) {
				flag2 = true;
				break;
			}
		}
		double secondPair [] = {i,Configration.slots[i].width*Configration.slots[i].depth};
		if(flag1||flag2) {
			if(firstPair[1]<secondPair[1])
				Configration.slots[(int) firstPair[0]].isActive = true;
			else 
				Configration.slots[(int) secondPair[0]].isActive = true;	
			Configration.slots[i].isActive = true; 
			Configration.slots[i].vehicle = new Vehicle(cw,cp,modelYear,id,modelName);
		}else {
			throw new Exception("there is no enough space!");
		}
	}

}
