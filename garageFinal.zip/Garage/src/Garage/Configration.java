package Garage;

public class Configration {
	private static boolean isFirstConf= false;
	static Park parkingAlgo = null;
	public static void setConfig(int confWay) {
		if(confWay ==1)
			parkingAlgo = new FirstIn(); 
		else if (confWay ==2)
			parkingAlgo = new MostFit(); 

	}
	public static Slot slots[];  
	public static void setSize(int size) {
		slots=new Slot[size];  	
		for(int i =0 ;i<size;i++) {
			slots[i] = new Slot(i+1);
		}
	}
	
	public static void setDimantion(double w,double d,int index) throws Exception {
		if(w<=0||d<=0)throw new Exception("Wrong dimantions!");
		Configration.slots[index].width = w;
		Configration.slots[index].depth = d;
	}
}
