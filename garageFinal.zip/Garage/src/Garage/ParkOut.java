package Garage;

public class ParkOut {
	
	static void parkOut(int slotID ){
		departure(Configration.slots[slotID]);
	}
	
	static void departure(Slot slot) {
		Vehicle vehicle = slot.vehicle;
		TimeDetector slotTime=vehicle.time; 
		vehicle.time.parkOutTime();
    	Display.displayTicket(slotTime.parkInTime,slotTime.parkOutTime,vehicle);
		slot.isActive = false;
	}
}
