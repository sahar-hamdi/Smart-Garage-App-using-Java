package Garage;

public class FirstIn extends Park {

	@Override
	 public void parkProcess(double cw, double cp, String modelYear, int id, String modelName) throws Exception {
		// TODO Auto-generated method stub
		boolean flag =false ; 
		for(int i =0 ;i<Configration.slots.length;i++) {
			if(cp<=Configration.slots[i].depth&& cw <= Configration.slots[i].width&&!Configration.slots[i].isActive) {
				flag = true;
				Configration.slots[i].isActive = true; 
				Configration.slots[i].vehicle = new Vehicle(cw,cp,modelYear,id, modelName);
				break;
			}
		}
		if(!flag)
			throw new Exception("there is no enough space!"); 
	}

}
