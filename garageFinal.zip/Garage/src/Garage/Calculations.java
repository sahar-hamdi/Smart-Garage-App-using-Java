package Garage;

import java.time.LocalDateTime;

public class Calculations {
	static long ticketPrice ; 
	static final long hourlyRate = 5;
	public static long  totalIncome ;
	
	static public long feez (long duration){
		
		long durationInHours = (duration+(60*60-1))/(60*60);
		ticketPrice = durationInHours * hourlyRate;
		totalIncome +=ticketPrice;
		return ticketPrice;
	}
	static public double durationInHours(long duration) {
		double convertInHours = (double) duration/(60*60);
		return convertInHours;
	}
}
