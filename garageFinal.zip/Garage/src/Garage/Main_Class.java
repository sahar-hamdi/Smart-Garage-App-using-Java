package Garage;


public class Main_Class {
	static public void main (String[] args) {
		Screen.confScreen(); 
		Screen.formPage();
	}
}

