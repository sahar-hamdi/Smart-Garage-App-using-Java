package Garage;

public abstract class Park {
	abstract void parkProcess(double cw,double cp,String modelYear,int id,String modelName ) throws Exception;
}
