package Garage;

import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class TimeDetector {
	
    private DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
    
    public LocalDateTime parkInTime,parkOutTime;
    Instant start,end;
    public long duration ; 
    public TimeDetector () {
    	
    	start = Instant.now();
    	
    	parkInTime = LocalDateTime.now();  
    }
    
    public void parkOutTime() {
    	parkOutTime = LocalDateTime.now();
    	
    	System.out.println(dtf.format(parkOutTime));      	
    	end = Instant.now();
    }
    public long durationInSeconds () {
    	duration = Duration.between(start, end).toSeconds();
    	return duration;
//    	System.out.println(duration);
    }
	
}
