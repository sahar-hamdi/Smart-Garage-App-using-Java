package Garage;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Comparator;

public class Display {

	public static void DisplayAvlislots() {
		Arrays.sort(Configration.slots,new Comparator<Slot>() {
			@Override
			public int compare(Slot o1, Slot o2) {
				return o1.getID() - o2.getID();
			}
		});
		for(int i =0 ;i<Configration.slots.length;i++) {
			if(!Configration.slots[i].isActive) {
				System.out.print(Configration.slots[i].getID());
				System.out.print (" ");				
			}
		}
		System.out.print('\n');
	}
	
	public static void dimantionsOfSlots() {
		for(int i =0 ;i<Configration.slots.length;i++) {
			System.out.println(Configration.slots[i].width+ " , "+Configration.slots[i].depth);
		}
	}
	
	public static void displayTicket(LocalDateTime parkInTime,LocalDateTime parkOutTime,Vehicle vehicle) {
		long duration = vehicle.time.durationInSeconds();
		long ticketPrice = Calculations.feez(duration);
		double convertInHours=  Calculations.durationInHours(duration);
		System.out.println("-------------------------------------------------------------------------------------");
		System.out.print("Start date: ");
		System.out.print(parkInTime);
		System.out.print("\tEnd date: ");
		System.out.println(parkOutTime);
		System.out.println();
		
		System.out.print("Duration: ");
		System.out.print(convertInHours+" H");
		System.out.print("\t\tThe ticket price is :");
		System.out.print(ticketPrice);
		System.out.println(" EGP\n");

		System.out.print("Model year: ");
		System.out.print(vehicle.modelYear);
		System.out.print("\t\t\t\t\tModel name: ");
		System.out.println(vehicle.modelName);
		System.out.println();
	
		System.out.println("-------------------------------------------------------------------------------------");
	}
}
